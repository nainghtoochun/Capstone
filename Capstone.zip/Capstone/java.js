// --- CONFIGURATION & STATE ---
const MAX_BUDGET = 150;
let currentState = {
    spent: 0,
    healthScore: 50, // 0-100 scale, starts neutral
    meals: {
        monday: { breakfast: null, lunch: null, dinner: null }
        // In full version, you'd have tuesday: {...}, etc.
    }
};

// Sample Database of Foods
// In a real app, this might come from a JSON file or API
const foodDatabase = [
    { id: 1, name: "Oatmeal & Berries", cost: 2.50, health: 5, type: "breakfast", img: "foods/oatmeal.svg" },
    { id: 2, name: "Sugary Cereal", cost: 4.00, health: -5, type: "breakfast", img: "foods/cereal.svg" },
    { id: 3, name: "Eggs & Toast", cost: 3.00, health: 4, type: "breakfast", img: "foods/egg.svg" },
    { id: 4, name: "Milk & Banana", cost: 1.80, health: 3, type: "breakfast", img: "foods/banana.svg" },

    { id: 10, name: "Grilled Chicken Salad", cost: 12.00, health: 8, type: "lunch", img: "foods/salad.svg" },
    { id: 11, name: "Ham Sandwich", cost: 6.50, health: 2, type: "lunch", img: "foods/sandwich.svg" },
    { id: 12, name: "Veggie Soup & Bread", cost: 5.50, health: 5, type: "lunch", img: "foods/soup.svg" },
    { id: 13, name: "Fast Food Burger", cost: 8.50, health: -7, type: "lunch", img: "foods/burger.svg" },

    { id: 20, name: "Salmon & Veggies", cost: 15.00, health: 10, type: "dinner", img: "foods/fish.svg" },
    { id: 21, name: "Chicken & Rice", cost: 9.50, health: 6, type: "dinner", img: "foods/chicken.svg" },
    { id: 22, name: "Pasta & Sauce", cost: 7.00, health: 1, type: "dinner", img: "foods/pasta.svg" },
    { id: 23, name: "Instant Ramen", cost: 1.50, health: -8, type: "dinner", img: "foods/ramen.svg" },

    // Snacks / extras (not yet slotted, but could be future expansion)
    { id: 30, name: "Apple", cost: 0.80, health: 2, type: "snack", img: "foods/apple.svg" },
    { id: 31, name: "Yogurt Cup", cost: 1.20, health: 2, type: "snack", img: "foods/yogurt.svg" },
    { id: 32, name: "Bread Loaf", cost: 2.20, health: 0, type: "snack", img: "foods/bread.svg" },
    { id: 33, name: "Pizza Slice", cost: 3.50, health: -3, type: "snack", img: "foods/pizza.svg" }
];

// --- INITIALIZATION ---
document.addEventListener('DOMContentLoaded', () => {
    populatePantry();
    updateDisplay();
});

function populatePantry() {
    const pantryContainer = document.getElementById('food-source');
    foodDatabase.forEach(food => {
        const foodEl = document.createElement('div');
        foodEl.className = 'food-item';
        foodEl.draggable = true;
        foodEl.dataset.id = food.id; // Store ID in the HTML

        foodEl.innerHTML = `
            <img class="food-thumb" src="${food.img}" alt="${food.name} icon" />
            <div class="food-info">
                <h4>${food.name}</h4>
                <p>Health: ${food.health > 0 ? '+' + food.health : food.health}</p>
                <p class="food-type">${food.type}</p>
            </div>
            <div class="food-cost">$${food.cost.toFixed(2)}</div>
        `;

        // Attach standard HTML5 drag event
        foodEl.addEventListener('dragstart', drag);
        pantryContainer.appendChild(foodEl);
    });
}

// --- DRAG AND DROP LOGIC ---
function allowDrop(ev) {
    ev.preventDefault(); // Necessary to allow a drop
    ev.currentTarget.classList.add('drag-over'); // Visual feedback
}

function drag(ev) {
    // Send the food ID when dragging starts
    ev.dataTransfer.setData("text/plain", ev.currentTarget.dataset.id);
}

// Optional: Remove drag-over styling if they leave the zone without dropping
document.querySelectorAll('.drop-zone').forEach(zone => {
    zone.addEventListener('dragleave', (ev) => {
        ev.currentTarget.classList.remove('drag-over');
    });
});

function drop(ev) {
    ev.preventDefault();
    const dropZone = ev.currentTarget;
    dropZone.classList.remove('drag-over');

    // 1. Get the data being dragged
    const foodId = parseInt(ev.dataTransfer.getData("text/plain"));
    const foodItem = foodDatabase.find(f => f.id === foodId);

    if (!foodItem) return;

    // 2. Identify which slot this is (e.g., "breakfast")
    const slotName = dropZone.closest('.meal-slot').dataset.slot;

    // 3. Update State (assign food to Monday's slot)
    // Note: If something was already there, we should theoretically "refund" it first.
    // For this simple prototype, we'll just overwrite it.
    currentState.meals.monday[slotName] = foodItem;

    // 4. Update UI for the Drop Zone
    dropZone.innerHTML = `
        <div class="selected-meal">
            <strong>${foodItem.name}</strong>
            <div>$${foodItem.cost.toFixed(2)}</div>
        </div>
    `;

    // 5. Recalculate all stats
    recalculateStats();
}

// --- CORE LOGIC ENGINE ---
function recalculateStats() {
    let totalCost = 0;
    let totalHealth = 50; // Reset to baseline before calculating

    // Loop through all days (just monday for now) and all slots
    Object.values(currentState.meals.monday).forEach(meal => {
        if (meal) {
            totalCost += meal.cost;
            totalHealth += meal.health;
        }
    });

    // Clamp health between 0 and 100
    currentState.spent = totalCost;
    currentState.healthScore = Math.max(0, Math.min(100, totalHealth));

    updateDisplay();
}

function updateDisplay() {
    // 1. Update Budget
    const budgetBar = document.getElementById('budget-bar');
    const spendText = document.getElementById('current-spend');
    const spendPercent = (currentState.spent / MAX_BUDGET) * 100;

    budgetBar.style.width = `${Math.min(spendPercent, 100)}%`;
    spendText.textContent = `$${currentState.spent.toFixed(2)}`;

    // Budget color feedback
    if (currentState.spent > MAX_BUDGET) {
        budgetBar.classList.remove('green', 'blue');
        budgetBar.classList.add('red'); // Over budget!
    } else {
        budgetBar.classList.remove('red', 'blue');
        budgetBar.classList.add('green');
    }

    // 2. Update Health
    const healthBar = document.getElementById('health-bar');
    const healthText = document.getElementById('health-text');
    const avatarEmoji = document.getElementById('avatar-emoji');

    healthBar.style.width = `${currentState.healthScore}%`;

    // Simple Avatar & Text feedback based on score
    if (currentState.healthScore > 75) {
        healthText.textContent = "Thriving!";
        avatarEmoji.textContent = "🤩"; // Happy/energetic
    } else if (currentState.healthScore < 30) {
        healthText.textContent = "Sluggish...";
        avatarEmoji.textContent = "🤢"; // Sick/tired
    } else {
        healthText.textContent = "Neutral";
        avatarEmoji.textContent = "😐"; // Neutral
    }
}
